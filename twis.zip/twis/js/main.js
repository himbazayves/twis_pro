
function Ben_way_to_get_element(el){
  return document.getElementById(el);
}

function ajax_changetab_and_send_data(php_file, el, send_data){
  var hr=new XMLHttpRequest();
  hr.open('POST', php_file, true);
  hr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

  hr.onreadystatechange=function(){
      if(hr.readyState==4 && hr.status==200){
          Ben_way_to_get_element(el).innerHTML=hr.responseText;
      }
  };

  hr.send(send_data);
}


function mySearchFunction1() {
  // Declare variables 
  var input, filter, table, tr, td, i;
  input = document.getElementById("Search");
  filter = input.value.toUpperCase();
  table = document.getElementById("Tb1");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    } 
  }
}

function mySearchFunction2() {
  // Declare variables 
  var input, filter, table, tr, td, i;
  input = document.getElementById("Search1");
  filter = input.value.toUpperCase();
  table = document.getElementById("Tb1");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[8];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    } 
  }
}

function login1(){

 Ben_way_to_get_element('Message1').innerHTML="<div class='alert alert-info' role='alert'><i class='fa fa-info-circle'></i> Authenticating …</div>";

 var username1=$('#username1').val();
 var password1=$('#password1').val();
 
 $.ajax({
     type:'POST',
     url: 'js/login1.php',
     data:{
         username1:username1,
         password1:password1,
 
     },
     
     success: function (response){
         $("#Message1").html(response);
     }
 
 });
 
 }

 $(document).ready(function(){

    // new agent

    $("#add_new_teacher").click(function(){
      $("#loader_general_admin1").fadeOut(500);  
      setTimeout(function(){ ajax_changetab_and_send_data('school_data/new_teacher.php', 'loader_general_admin', null); }, 500);
      });

    // new room

    $("#add_new_room").click(function(){
      $("#loader_general_admin1").fadeOut(500);  
      setTimeout(function(){ ajax_changetab_and_send_data('hotels_data/new_room.php', 'loader_general_admin', null); }, 500);
      });


});

 // new teacher

function new_teacher(){
        Ben_way_to_get_element('Message2').innerHTML="<div class='alert alert-info' role='alert'><i class='fa fa-info-circle'></i> Saving New Teacher . . . . </div>";
      
        var formdata=new FormData();
        var ajax1=new XMLHttpRequest();

        var t_username=Ben_way_to_get_element('t_username').value;
        var t_pass=Ben_way_to_get_element('t_pass').value;
        var tel=Ben_way_to_get_element('tel').value;
        var school=Ben_way_to_get_element('school').value;
      
        formdata.append('t_username',t_username);
        formdata.append('t_pass',t_pass);
        formdata.append('tel',tel);
        formdata.append('school',school);
      
        ajax1.open('POST', 'teacher_data/new_teacher_data.php'); //third argument can be true or false which is optional
        ajax1.send(formdata);
      
        ajax1.onreadystatechange=function(){
            Ben_way_to_get_element('Message2').innerHTML=ajax1.responseText;
      
        }; 
}

// agent update profile

function update_user_profile() {
          Ben_way_to_get_element('profile_complete_message').innerHTML = "<div class='alert alert-info' role='alert'><i class='fa fa-info-circle'></i> Updating Profile . . . . . . </div>";

          var formdata = new FormData();
          var ajax1 = new XMLHttpRequest();

          var username = Ben_way_to_get_element('username').value;
          var agent_id = Ben_way_to_get_element('agent_id').value;
          var tel=Ben_way_to_get_element('tel').value;
          var email=Ben_way_to_get_element('email').value;
          var password=Ben_way_to_get_element('password').value;
          var profile = Ben_way_to_get_element('profile').files[0];

          formdata.append('username', username);
          formdata.append('agent_id', agent_id);
          formdata.append('tel', tel);
          formdata.append('email', email);
          formdata.append('password', password);
          formdata.append('profile', profile);

          ajax1.open('POST', 'agent_data/update_profile_data.php'); //third argument can be true or false which is optional
          ajax1.send(formdata);

          ajax1.onreadystatechange = function () {
            Ben_way_to_get_element('profile_complete_message').innerHTML = ajax1.responseText;

      };
}

// teacher update profile

function teacher_update_profile() {
          Ben_way_to_get_element('profile_complete_message').innerHTML = "<div class='alert alert-info' role='alert'><i class='fa fa-info-circle'></i> Updating Profile . . . . . . </div>";

          var formdata = new FormData();
          var ajax1 = new XMLHttpRequest();

          var t_id = Ben_way_to_get_element('t_id').value;
          var username = Ben_way_to_get_element('username').value;
          var f_name = Ben_way_to_get_element('f_name').value;
          var l_name=Ben_way_to_get_element('l_name').value;
          var email=Ben_way_to_get_element('email').value;
          var tel=Ben_way_to_get_element('tel').value;
          var password=Ben_way_to_get_element('password').value;
          var profile = Ben_way_to_get_element('profile').files[0];

          formdata.append('t_id', t_id);
          formdata.append('username', username);
          formdata.append('f_name', f_name);
          formdata.append('l_name', l_name);
          formdata.append('email', email);
          formdata.append('tel', tel);
          formdata.append('password', password);
          formdata.append('profile', profile);

          ajax1.open('POST', 'teacher_data/profile_update_data.php'); //third argument can be true or false which is optional
          ajax1.send(formdata);

          ajax1.onreadystatechange = function () {
            Ben_way_to_get_element('profile_complete_message').innerHTML = ajax1.responseText;

      };
}

// parent update profile

function parent_update_profile() {
          Ben_way_to_get_element('profile_complete_message').innerHTML = "<div class='alert alert-info' role='alert'><i class='fa fa-info-circle'></i> Updating Profile . . . . . . </div>";

          var formdata = new FormData();
          var ajax1 = new XMLHttpRequest();

          var t_id = Ben_way_to_get_element('t_id').value;
          var username = Ben_way_to_get_element('username').value;
          var f_name = Ben_way_to_get_element('f_name').value;
          var l_name=Ben_way_to_get_element('l_name').value;
          var email=Ben_way_to_get_element('email').value;
          var tel=Ben_way_to_get_element('tel').value;
          var password=Ben_way_to_get_element('password').value;
          var profile = Ben_way_to_get_element('profile').files[0];

          formdata.append('t_id', t_id);
          formdata.append('username', username);
          formdata.append('f_name', f_name);
          formdata.append('l_name', l_name);
          formdata.append('email', email);
          formdata.append('tel', tel);
          formdata.append('password', password);
          formdata.append('profile', profile);

          ajax1.open('POST', 'parent_data/profile_update_data.php'); //third argument can be true or false which is optional
          ajax1.send(formdata);

          ajax1.onreadystatechange = function () {
            Ben_way_to_get_element('profile_complete_message').innerHTML = ajax1.responseText;

      };
}


// new student from teacher

function teacher_new_student() {
          Ben_way_to_get_element('profile_complete_message').innerHTML = "<div class='alert alert-info' role='alert'><i class='fa fa-info-circle'></i> Updating Profile . . . . . . </div>";

          var formdata = new FormData();
          var ajax1 = new XMLHttpRequest();

          var school = Ben_way_to_get_element('school').value;
          var s_class = Ben_way_to_get_element('s_class').value;
          var s_username = Ben_way_to_get_element('s_username').value;
          var s_Fname = Ben_way_to_get_element('s_Fname').value;
          var s_Lname=Ben_way_to_get_element('s_Lname').value;
          var s_sex=Ben_way_to_get_element('s_sex').value;
          var s_pass=Ben_way_to_get_element('s_pass').value;
          var profile = Ben_way_to_get_element('profile').files[0];

          formdata.append('school', school);
          formdata.append('s_class', s_class);
          formdata.append('s_username', s_username);
          formdata.append('s_Fname', s_Fname);
          formdata.append('s_Lname', s_Lname);
          formdata.append('s_sex', s_sex);
          formdata.append('s_pass', s_pass);
          formdata.append('profile', profile);

          ajax1.open('POST', 'student_data/new_student_data.php'); //third argument can be true or false which is optional
          ajax1.send(formdata);

          ajax1.onreadystatechange = function () {
            Ben_way_to_get_element('profile_complete_message').innerHTML = ajax1.responseText;

      };
}

// new student from teacher

function parent_new_student() {
          Ben_way_to_get_element('profile_complete_message').innerHTML = "<div class='alert alert-info' role='alert'><i class='fa fa-info-circle'></i> Updating Profile . . . . . . </div>";

          var formdata = new FormData();
          var ajax1 = new XMLHttpRequest();

          var school = Ben_way_to_get_element('school').value;
          var s_class = Ben_way_to_get_element('s_class').value;
          var s_username = Ben_way_to_get_element('s_username').value;
          var s_Fname = Ben_way_to_get_element('s_Fname').value;
          var s_Lname=Ben_way_to_get_element('s_Lname').value;
          var s_sex=Ben_way_to_get_element('s_sex').value;
          var s_pass=Ben_way_to_get_element('s_pass').value;
          var profile = Ben_way_to_get_element('profile').files[0];

          formdata.append('school', school);
          formdata.append('s_class', s_class);
          formdata.append('s_username', s_username);
          formdata.append('s_Fname', s_Fname);
          formdata.append('s_Lname', s_Lname);
          formdata.append('s_sex', s_sex);
          formdata.append('s_pass', s_pass);
          formdata.append('profile', profile);

          ajax1.open('POST', 'child_data/new_child_data.php'); //third argument can be true or false which is optional
          ajax1.send(formdata);

          ajax1.onreadystatechange = function () {
            Ben_way_to_get_element('profile_complete_message').innerHTML = ajax1.responseText;

      };
}

// new school

function new_school(){
        Ben_way_to_get_element('new_client_message').innerHTML="<div class='alert alert-info' role='alert'><i class='fa fa-info-circle'></i> Creating New Account for you . . . . </div>";
      
        var formdata=new FormData();
        var ajax1=new XMLHttpRequest();

        var email=Ben_way_to_get_element('email').value;
        var username=Ben_way_to_get_element('username').value;
        var password=Ben_way_to_get_element('password').value;
      
        formdata.append('email',email);
        formdata.append('username',username);
        formdata.append('password',password);
      
        ajax1.open('POST', 'school/school_data/new_client.php'); //third argument can be true or false which is optional
        ajax1.send(formdata);
      
        ajax1.onreadystatechange=function(){
            Ben_way_to_get_element('new_client_message').innerHTML=ajax1.responseText;
      
        }; 
}

// new parent

function new_parent(){
        Ben_way_to_get_element('new_client_message').innerHTML="<div class='alert alert-info' role='alert'><i class='fa fa-info-circle'></i> Creating New Account for you . . . . </div>";
      
        var formdata=new FormData();
        var ajax1=new XMLHttpRequest();

        var email=Ben_way_to_get_element('email').value;
        var username=Ben_way_to_get_element('username').value;
        var password=Ben_way_to_get_element('password').value;
      
        formdata.append('email',email);
        formdata.append('username',username);
        formdata.append('password',password);
      
        ajax1.open('POST', 'parent/parent_data/new_client.php'); //third argument can be true or false which is optional
        ajax1.send(formdata);
      
        ajax1.onreadystatechange=function(){
            Ben_way_to_get_element('new_client_message').innerHTML=ajax1.responseText;
      
        }; 
}

// new hotel or tours

function new_hotel_tours(){
        Ben_way_to_get_element('new_client_message').innerHTML="<div class='alert alert-info' role='alert'><i class='fa fa-info-circle'></i> Creating New Account for you . . . . </div>";
      
        var formdata=new FormData();
        var ajax1=new XMLHttpRequest();

        var email=Ben_way_to_get_element('email').value;
        var username=Ben_way_to_get_element('username').value;
        var contact=Ben_way_to_get_element('contact').value;
        var role=Ben_way_to_get_element('role').value;
        var password=Ben_way_to_get_element('password').value;
      
        formdata.append('email',email);
        formdata.append('username',username);
        formdata.append('contact',contact);
        formdata.append('role',role);
        formdata.append('password',password);
      
        ajax1.open('POST', 'hotels/hotels_data/new_client.php'); //third argument can be true or false which is optional
        ajax1.send(formdata);
      
        ajax1.onreadystatechange=function(){
            Ben_way_to_get_element('new_client_message').innerHTML=ajax1.responseText;
      
        }; 
      }


// hotel completion of profile

function complete_reg_profile() {
          Ben_way_to_get_element('profile_complete_message').innerHTML = "<div class='alert alert-info' role='alert'><i class='fa fa-info-circle'></i> Completing Profile . . . . . . </div>";

          var formdata = new FormData();
          var ajax1 = new XMLHttpRequest();

          var h_name = Ben_way_to_get_element('h_name').value;
          var h_country=Ben_way_to_get_element('h_country').value;
          var account_id=Ben_way_to_get_element('account_id').value;
          var h_city=Ben_way_to_get_element('h_city').value;
          var h_stand=Ben_way_to_get_element('h_stand').value;
          var h_manager=Ben_way_to_get_element('h_manager').value;

          formdata.append('h_name', h_name);
          formdata.append('h_country', h_country);
          formdata.append('account_id', account_id);
          formdata.append('h_city', h_city);
          formdata.append('h_stand', h_stand);
          formdata.append('h_manager', h_manager);

          ajax1.open('POST', 'hotels_data/complete_profile_data.php'); //third argument can be true or false which is optional
          ajax1.send(formdata);

          ajax1.onreadystatechange = function () {
            Ben_way_to_get_element('profile_complete_message').innerHTML = ajax1.responseText;

      };
}


// Agent accept hotel to work 

function accept_hotel_to_work() {
          Ben_way_to_get_element('hotel_invitation_complete_message').innerHTML = "<div class='alert alert-info' role='alert'><i class='fa fa-info-circle'></i> Updating Profile . . . . . . </div>";

          var formdata = new FormData();
          var ajax1 = new XMLHttpRequest();

          var agent_data = Ben_way_to_get_element('agent_data').value;
          var hotel_data = Ben_way_to_get_element('hotel_data').value;

          formdata.append('agent_data', agent_data);
          formdata.append('hotel_data', hotel_data);

          ajax1.open('POST', 'agent_data/accept_hotel_invitation.php'); //third argument can be true or false which is optional
          ajax1.send(formdata);

          ajax1.onreadystatechange = function () {
            Ben_way_to_get_element('hotel_invitation_complete_message').innerHTML = ajax1.responseText;

      };
}

// Agent accept tour to work 

function accept_tour_to_work() {
          Ben_way_to_get_element('hotel_invitation_complete_message').innerHTML = "<div class='alert alert-info' role='alert'><i class='fa fa-info-circle'></i> Updating Profile . . . . . . </div>";

          var formdata = new FormData();
          var ajax1 = new XMLHttpRequest();

          var agent_data = Ben_way_to_get_element('agent_data').value;
          var hotel_data = Ben_way_to_get_element('hotel_data').value;

          formdata.append('agent_data', agent_data);
          formdata.append('hotel_data', hotel_data);

          ajax1.open('POST', 'agent_data/accept_tour_invitation.php'); //third argument can be true or false which is optional
          ajax1.send(formdata);

          ajax1.onreadystatechange = function () {
            Ben_way_to_get_element('hotel_invitation_complete_message').innerHTML = ajax1.responseText;

      };
}



// update Agent

function update_agent(adminid){
    $("#loader_general_admin1").fadeOut(500);  
    setTimeout(function(){
      var staff=Ben_way_to_get_element(adminid).innerHTML;
      var send_data1=
          "&staff="+staff;
     ajax_changetab_and_send_data('master_data/update_agent.php', 'loader_general_admin', send_data1); 
    }, 500);
}

// delete Agent
function delete_agent_data(adminid){
    $("#loader_general_admin1").fadeOut(500);  
    setTimeout(function(){
      var staff=Ben_way_to_get_element(adminid).innerHTML;
      var send_data1=
          "&staff="+staff;
     ajax_changetab_and_send_data('master_data/delete_agent_data.php', 'loader_general_admin', send_data1); 
    }, 500);
}

// delete room
function delete_room_data(adminid){
    $("#loader_general_admin1").fadeOut(500);  
    setTimeout(function(){
      var room_account_id=Ben_way_to_get_element(adminid).innerHTML;
      var send_data1=
          "&room_account_id="+room_account_id;
     ajax_changetab_and_send_data('hotels_data/delete_room.php', 'loader_general_admin', send_data1); 
    }, 500);
}

// change room status to occupied
function change_room_status_data(adminid){
    $("#loader_general_admin1").fadeOut(500);  
    setTimeout(function(){
      var room_account_id=Ben_way_to_get_element(adminid).innerHTML;
      var send_data1=
          "&room_account_id="+room_account_id;
     ajax_changetab_and_send_data('hotels_data/available_room_stat.php', 'loader_general_admin', send_data1); 
    }, 500);
}

// change room status to available
function update_room_status_data(adminid){
    $("#loader_general_admin1").fadeOut(500);  
    setTimeout(function(){
      var room_account_id=Ben_way_to_get_element(adminid).innerHTML;
      var send_data1=
          "&room_account_id="+room_account_id;
     ajax_changetab_and_send_data('hotels_data/occupied_room_change_data.php', 'loader_general_admin', send_data1); 
    }, 500);
}

// update room

function update_room(adminid){
    $("#loader_general_admin1").fadeOut(500);  
    setTimeout(function(){
      var room_account_id=Ben_way_to_get_element(adminid).innerHTML;
      var send_data1=
          "&room_account_id="+room_account_id;
     ajax_changetab_and_send_data('hotels_data/update_room.php', 'loader_general_admin', send_data1); 
    }, 500);
}

// update Agent data

function update_agent_data(){
  Ben_way_to_get_element('Message2').innerHTML="<div class='alert alert-info' role='alert'><i class='fa fa-info-circle'></i> Updating Staff Member Data . . . . </div>";

  var formdata=new FormData();
  var ajax1=new XMLHttpRequest();

  var staff=Ben_way_to_get_element('staff').value;
  var name=Ben_way_to_get_element('name').value;
  var pass=Ben_way_to_get_element('pass').value;
  var email=Ben_way_to_get_element('email').value;
  var tel=Ben_way_to_get_element('tel').value;

  formdata.append('staff',staff);
  formdata.append('name',name);
  formdata.append('pass',pass);
  formdata.append('email',email);
  formdata.append('tel',tel);

  ajax1.open('POST', 'master_data/update_agent_data.php'); //third argument can be true or false which is optional
  ajax1.send(formdata);

  ajax1.onreadystatechange=function(){
      Ben_way_to_get_element('Message2').innerHTML=ajax1.responseText;

  }; 
}
